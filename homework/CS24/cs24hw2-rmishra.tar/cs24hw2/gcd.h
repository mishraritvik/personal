/*
 * This is a stub header for gcd.s
 */
int gcd(int arg1, int arg2);
