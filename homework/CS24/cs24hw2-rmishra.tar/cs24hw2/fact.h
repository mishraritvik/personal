/*
 * This is a stub header for fact.s
 */
int fact(int arg);
