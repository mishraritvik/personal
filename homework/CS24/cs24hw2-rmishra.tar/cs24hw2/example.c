int ex(int a, int b, int c, int d) {
  int res;
  res = a * (b - c) + d;
  return res;
}

